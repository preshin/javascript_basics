var roundUp=1.5;
rounded=Math.round(roundUp);
console.log(rounded);
