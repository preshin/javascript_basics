var example = 'pizza is alright';
     example = example.replace('alright','wonderful');
     console.log(example);
