var pizzaToppings=['tomato sauce','cheese', 'pepperoni'];
console.log(pizzaToppings);
