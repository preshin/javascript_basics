var food = ['apple', 'pizza', 'pear'];
console.log(food[1]);
