var example;
example='some string';
console.log(example);
